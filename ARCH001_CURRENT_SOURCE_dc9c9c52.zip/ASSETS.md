# Jewel Dash Assets

**Art direction:** polished mobile game-engine scene in midnight blue with clean cyan holographic architecture and warm gold Jewel accents. The playfield uses three explicit lanes, a gold-and-cyan jewel orb, cyan sector gates, gold shard pickups, and dark barriers with small red warnings. The composition must remain spare enough for phone controls and score HUD.

| Asset | Role | URL / status |
|---|---|---|
| Jewel Dash visual target | Visual QA target and optional backdrop texture | `/manus-storage/arch001-jewel-dash-visual-target_8eaf0e54.png` — generation in progress; use the stable URL directly. |
