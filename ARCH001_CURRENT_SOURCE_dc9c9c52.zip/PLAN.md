# Game Plan: ARCH-001 Jewel Dash

## Product frame

**ARCH-001 Jewel Dash** is a lightweight portrait browser game designed first for a mobile touch screen. It is not a native-store package. The player guides the Original Jewel through three lanes of Bashosha City, gathers gold fragments, crosses cyan district gates, and avoids blocked lanes. The game is a separate `/game` experience; it does not write to, modify, or infer anything about the DNA LOCK registry.

## Risk Tasks

### 1. Mobile lane input and responsive canvas

- **Why isolated:** touch swipes, keyboard fallback, and narrow portrait viewports must map to the same lane movement without accidental repeated movement or UI overflow.
- **Approach:** use a three-lane state (`0`, `1`, `2`) with semantic left/right actions. Accept touch swipe direction on the canvas, plus keyboard arrows and on-screen buttons. Render Babylon inside a lifecycle-safe React canvas and place React HUD controls over it.
- **Verify:** a left swipe moves exactly one lane left; a right swipe moves exactly one lane right; lane limits prevent escape; arrow keys and touch buttons produce the same move; portrait and desktop previews remain readable.

### 2. Deterministic moving-object loop

- **Why isolated:** score, collision, restart, and screenshot proof need a stable reproducible run rather than random timing failures.
- **Approach:** use a seeded repeating spawn sequence for three object types: `shard`, `gate`, and `barrier`. Objects travel toward the player; the game updates score and streak on valid contacts, loses a shield on barrier collision, and restarts with one tap. The `?demo` flag automatically cycles lanes safely for verification.
- **Verify:** shards add score, gates add a streak bonus, barriers remove one shield, three barrier hits end the run, and `?demo` visibly advances the score with no manual input.

## Main Build

Build a full-screen portrait game route with a small Babylon city-road scene, the gold/cyan jewel player, moving collectible shards, district gates, barriers, score/shield HUD, large touch controls, pause/restart state, and a route back to ARCH-001 Operations.

- **Assets needed:** one generated 9:16 visual target used as the art-direction reference and optional scene background texture. The gameplay meshes remain procedural for fast mobile loading.
- **Verify:**
  - Player movement follows touch and keyboard input exactly.
  - Score increments on shard collection and gate crossing.
  - Barrier collision updates shields and game-over state.
  - Touch controls and text fit a 375×812 mobile viewport.
  - No missing texture placeholders or browser console errors.
  - Visual consistency with the reference: midnight blue city, cyan gates, gold jewel cues, three clear lanes, readable HUD.
  - `?demo` demonstrates gameplay in a screenshot.
