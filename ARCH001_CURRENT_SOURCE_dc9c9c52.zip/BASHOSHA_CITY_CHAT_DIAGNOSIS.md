# Bashosha City Chat — Diagnostic Report

## Scope

| Item | Verified value |
|---|---|
| Public interface | `https://cessar123.github.io/bashosha-city/` |
| Static source | `Cessar123/bashosha-city`, `index.html` |
| Chat endpoint | `https://arch-001-ai.saedseleem5.workers.dev` |
| AI Worker | `arch-001-ai` in the Saedseleem5 Cloudflare account |

## Confirmed root cause

The GitHub Pages interface is healthy: it sends a JSON `POST` request to the Worker and Cloudflare's CORS preflight returns `200` with `POST, OPTIONS` allowed. The actual Worker request returns **HTTP 500**, with the JSON error `ARCH-001 AI connection failed`.

The Worker reports that `@cf/meta/llama-3.1-8b-instruct` was deprecated on **2026-05-30**. Therefore, the error happens in the AI Worker, not in the Bashosha City user interface and not because of GitHub Pages.

## Minimal safe repair

In the Cloudflare Worker `arch-001-ai`, replace the deprecated model identifier:

```js
// Deprecated — causes the current HTTP 500 response
"@cf/meta/llama-3.1-8b-instruct"

// Directly compatible replacement for the existing messages-based call
"@cf/meta/llama-3.1-8b-instruct-fast"
```

The fast variant accepts the same `env.AI.run(model, { messages })` pattern and returns a `response` string, so the current front-end parser already supports its normal response shape. A more capable optional future upgrade is `@cf/zai-org/glm-4.7-flash`, but the fast Llama replacement is the lowest-risk repair because it preserves the existing integration contract.

## Front-end hardening recommended

Keep the current response parsing, but insert this check immediately after the `fetch` call so HTTP failures cannot be presented as a vague AI reply:

```js
if (!response.ok) {
  const failure = await response.json().catch(() => ({}));
  throw new Error(failure.details || failure.error || `HTTP ${response.status}`);
}
```

## Verification after the Worker change

Send a short chat message from the public Bashosha City page. A successful response must have status `200` and a JSON body containing either `response` or another field already handled by the front-end. Do not change the Foxy or ARCH-001 canon prompt as part of this infrastructure repair.

## Current deployment status

No successful Worker deployment was made from this repair session. The attempted invalid editor draft was rejected by Cloudflare before deployment, so it did not harm the live service.

The Worker was re-tested afterwards with a short diagnostic message and returned **HTTP 200** with a valid JSON `response`. The Foxy chat path is therefore working again. The restoration appears to have been made through another valid deployment path; no further Worker edit is required from this session.

## References

[1] [Cloudflare — Planned Workers AI model deprecations](https://developers.cloudflare.com/changelog/post/2026-05-08-planned-model-deprecations/)

[2] [Cloudflare — Llama 3.1 8B Instruct Fast model reference](https://developers.cloudflare.com/workers-ai/models/llama-3.1-8b-instruct-fast/)

[3] [Cloudflare — GLM-4.7-Flash model reference](https://developers.cloudflare.com/workers-ai/models/glm-4.7-flash/)
