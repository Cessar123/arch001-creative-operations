import { ArrowLeft, ArrowRight, RotateCcw, Shield, Sparkles } from "lucide-react";
import { useCallback, useMemo, useRef, useState } from "react";
import { Link, useLocation } from "wouter";
import GameCanvas, { type GameCanvasHandle } from "@/components/GameCanvas";
import { initialDashSnapshot } from "@/game/jewelDash/rules";
import type { DashSnapshot } from "@/game/jewelDash/types";

const VISUAL_TARGET_URL = "/manus-storage/arch001-jewel-dash-visual-target_8eaf0e54.png";

export default function JewelDash() {
  const [, setLocation] = useLocation();
  const controllerRef = useRef<GameCanvasHandle>(null);
  const [snapshot, setSnapshot] = useState<DashSnapshot>(() => initialDashSnapshot());
  const demo = useMemo(() => new URLSearchParams(window.location.search).has("demo"), []);
  const onSnapshot = useCallback((next: DashSnapshot) => setSnapshot(next), []);

  return (
    <main
      className="relative min-h-dvh overflow-hidden bg-[#020b16] text-white"
      style={{ backgroundImage: `linear-gradient(180deg, rgba(2, 11, 22, 0.78), rgba(2, 11, 22, 0.97)), url(${VISUAL_TARGET_URL})`, backgroundSize: "cover", backgroundPosition: "center" }}
    >
      <GameCanvas ref={controllerRef} demo={demo} onSnapshot={onSnapshot} />

      <section className="pointer-events-none relative z-10 mx-auto flex min-h-dvh w-full max-w-md flex-col justify-between px-4 pb-5 pt-[max(1.15rem,env(safe-area-inset-top))]">
        <header className="flex items-start justify-between gap-3">
          <button onClick={() => setLocation("/")} className="pointer-events-auto rounded-2xl border border-cyan-300/30 bg-slate-950/70 px-3 py-2 text-xs font-semibold text-cyan-100 backdrop-blur" aria-label="العودة لغرفة العمليات">
            غرفة العمليات
          </button>
          <div className="rounded-2xl border border-amber-300/35 bg-slate-950/70 px-3 py-2 text-right backdrop-blur">
            <p className="text-[10px] tracking-[0.2em] text-cyan-300">ARCH-001</p>
            <h1 className="text-sm font-black text-amber-200">JEWEL DASH</h1>
          </div>
        </header>

        <div className="space-y-3">
          <div className="grid grid-cols-3 gap-2">
            <div className="rounded-2xl border border-amber-300/30 bg-slate-950/75 p-3 backdrop-blur">
              <p className="text-[10px] text-slate-400">النقاط</p>
              <p className="mt-1 text-xl font-black text-amber-200">{snapshot.score}</p>
            </div>
            <div className="rounded-2xl border border-cyan-300/30 bg-slate-950/75 p-3 backdrop-blur">
              <p className="text-[10px] text-slate-400">السلسلة</p>
              <p className="mt-1 text-xl font-black text-cyan-200">{snapshot.streak}</p>
            </div>
            <div className="rounded-2xl border border-cyan-300/30 bg-slate-950/75 p-3 backdrop-blur">
              <p className="text-[10px] text-slate-400">الدروع</p>
              <p className="mt-1 flex items-center gap-1 text-xl font-black text-cyan-100"><Shield size={16} /> {snapshot.shields}</p>
            </div>
          </div>

          <div className="rounded-2xl border border-cyan-300/25 bg-slate-950/75 px-4 py-3 text-center text-sm font-semibold text-cyan-100 backdrop-blur">
            {snapshot.signal}
          </div>

          {snapshot.status === "GAME_OVER" ? (
            <div className="pointer-events-auto rounded-3xl border border-amber-300/45 bg-slate-950/90 p-5 text-center shadow-2xl backdrop-blur">
              <Sparkles className="mx-auto mb-2 text-amber-300" />
              <h2 className="text-xl font-black text-amber-100">أعد شحن الجوهرة</h2>
              <p className="mt-1 text-sm text-slate-300">جمعت {snapshot.score} نقطة داخل بشوشا سيتي.</p>
              <button onClick={() => controllerRef.current?.restart()} className="mt-4 inline-flex items-center gap-2 rounded-2xl bg-amber-300 px-5 py-3 font-black text-slate-950">
                <RotateCcw size={17} /> إعادة التشغيل
              </button>
            </div>
          ) : (
            <div className="pointer-events-auto grid grid-cols-2 gap-3">
              <button onClick={() => controllerRef.current?.move("LEFT")} className="flex items-center justify-center gap-2 rounded-2xl border border-cyan-200/45 bg-cyan-300/15 py-4 font-black text-cyan-50 backdrop-blur active:scale-[0.97]">
                <ArrowLeft size={21} /> يسار
              </button>
              <button onClick={() => controllerRef.current?.move("RIGHT")} className="flex items-center justify-center gap-2 rounded-2xl border border-cyan-200/45 bg-cyan-300/15 py-4 font-black text-cyan-50 backdrop-blur active:scale-[0.97]">
                يمين <ArrowRight size={21} />
              </button>
            </div>
          )}

          <p className="text-center text-[10px] text-cyan-100/65">اسحب يميناً أو يساراً — اجمع الذهب واعبر بوابات القطاعات</p>
          <Link href="/" className="pointer-events-auto block text-center text-[11px] text-amber-200/85 underline underline-offset-4">عودة إلى ARCH-001 Operations</Link>
        </div>
      </section>
    </main>
  );
}
