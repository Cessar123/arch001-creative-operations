import { forwardRef, useEffect, useImperativeHandle, useRef } from "react";
import { loadBabylonRuntime } from "@/game/jewelDash/babylonRuntime";
import { createJewelDashScene, type JewelDashHandle } from "@/game/jewelDash/scene";
import type { DashDirection, DashSnapshot } from "@/game/jewelDash/types";

export type GameCanvasHandle = {
  move: (direction: DashDirection) => void;
  restart: () => void;
};

type GameCanvasProps = {
  demo: boolean;
  onSnapshot: (snapshot: DashSnapshot) => void;
  onSwipe?: (direction: DashDirection) => void;
};

const GameCanvas = forwardRef<GameCanvasHandle, GameCanvasProps>(function GameCanvas({ demo, onSnapshot, onSwipe }, ref) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const startedRef = useRef(false);
  const gameRef = useRef<JewelDashHandle | null>(null);
  const onSnapshotRef = useRef(onSnapshot);
  const onSwipeRef = useRef(onSwipe);
  onSnapshotRef.current = onSnapshot;
  onSwipeRef.current = onSwipe;

  useImperativeHandle(ref, () => ({
    move: (direction) => gameRef.current?.move(direction),
    restart: () => gameRef.current?.restart(),
  }));

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || startedRef.current) return;
    startedRef.current = true;
    let engine: any = null;
    let startX = 0;
    let handle: JewelDashHandle | null = null;
    let cancelled = false;

    loadBabylonRuntime()
      .then((B) => {
        if (cancelled) return null;
        engine = new B.Engine(canvas, true, { preserveDrawingBuffer: true, stencil: true, adaptToDeviceRatio: true });
        return createJewelDashScene(engine, canvas, { demo, onSnapshot: (snapshot) => onSnapshotRef.current(snapshot) });
      })
      .then((created) => {
        if (!created || cancelled) return;
        handle = created;
        gameRef.current = created;
        engine.runRenderLoop(() => created.scene.render());
      })
      .catch(() => onSnapshotRef.current({ score: 0, shields: 0, lane: 1, streak: 0, status: "GAME_OVER", signal: "تعذر تحميل محرك اللعبة" }));

    const onResize = () => engine?.resize();
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "ArrowLeft") gameRef.current?.move("LEFT");
      if (event.key === "ArrowRight") gameRef.current?.move("RIGHT");
      if (event.key.toLowerCase() === "r") gameRef.current?.restart();
    };
    const onTouchStart = (event: TouchEvent) => {
      startX = event.changedTouches[0]?.clientX ?? 0;
    };
    const onTouchEnd = (event: TouchEvent) => {
      const endX = event.changedTouches[0]?.clientX ?? startX;
      if (Math.abs(endX - startX) < 20) return;
      const direction: DashDirection = endX < startX ? "LEFT" : "RIGHT";
      gameRef.current?.move(direction);
      onSwipeRef.current?.(direction);
    };

    window.addEventListener("resize", onResize);
    window.addEventListener("keydown", onKeyDown);
    canvas.addEventListener("touchstart", onTouchStart, { passive: true });
    canvas.addEventListener("touchend", onTouchEnd, { passive: true });

    return () => {
      cancelled = true;
      window.removeEventListener("resize", onResize);
      window.removeEventListener("keydown", onKeyDown);
      canvas.removeEventListener("touchstart", onTouchStart);
      canvas.removeEventListener("touchend", onTouchEnd);
      handle?.dispose();
      gameRef.current = null;
      engine?.dispose();
      startedRef.current = false;
    };
  }, [demo]);

  return <canvas ref={canvasRef} className="absolute inset-0 h-full w-full outline-none" style={{ touchAction: "none" }} />;
});

export default GameCanvas;
