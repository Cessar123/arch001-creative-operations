import type { DashObjectKind, DashSnapshot } from "./types";

export const LANE_POSITIONS = [-3, 0, 3] as const;

export const initialDashSnapshot = (): DashSnapshot => ({
  score: 0,
  shields: 3,
  lane: 1,
  streak: 0,
  status: "RUNNING",
  signal: "ابدأ جمع شظايا الجوهرة",
});

export function resolveContact(snapshot: DashSnapshot, kind: DashObjectKind): DashSnapshot {
  if (kind === "shard") {
    return {
      ...snapshot,
      score: snapshot.score + 12,
      streak: snapshot.streak + 1,
      signal: "+12 شظية جوهرة",
    };
  }

  if (kind === "gate") {
    const bonus = 20 + snapshot.streak * 4;
    return {
      ...snapshot,
      score: snapshot.score + bonus,
      streak: snapshot.streak + 1,
      signal: `بوابة قطاع +${bonus}`,
    };
  }

  const shields = Math.max(0, snapshot.shields - 1);
  return {
    ...snapshot,
    shields,
    streak: 0,
    status: shields === 0 ? "GAME_OVER" : "RUNNING",
    signal: shields === 0 ? "انطفأت الدروع — اضغط إعادة التشغيل" : "حاجز! خسرت درعاً",
  };
}
