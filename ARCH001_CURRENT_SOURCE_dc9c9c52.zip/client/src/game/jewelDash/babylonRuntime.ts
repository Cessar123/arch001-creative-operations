declare global {
  interface Window {
    BABYLON?: any;
    __arch001BabylonLoader?: Promise<any>;
  }
}

export function loadBabylonRuntime(): Promise<any> {
  if (window.BABYLON) return Promise.resolve(window.BABYLON);
  if (window.__arch001BabylonLoader) return window.__arch001BabylonLoader;

  window.__arch001BabylonLoader = new Promise((resolve, reject) => {
    const script = document.createElement("script");
    script.src = "https://cdn.babylonjs.com/babylon.js";
    script.async = true;
    script.onload = () => (window.BABYLON ? resolve(window.BABYLON) : reject(new Error("Babylon runtime was unavailable")));
    script.onerror = () => reject(new Error("Could not load Babylon runtime"));
    document.head.appendChild(script);
  });

  return window.__arch001BabylonLoader;
}
