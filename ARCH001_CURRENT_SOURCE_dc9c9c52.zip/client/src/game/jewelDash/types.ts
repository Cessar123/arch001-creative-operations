export type DashObjectKind = "shard" | "gate" | "barrier";

export type DashStatus = "RUNNING" | "GAME_OVER";

export type DashSnapshot = {
  score: number;
  shields: number;
  lane: number;
  streak: number;
  status: DashStatus;
  signal: string;
};

export type DashDirection = "LEFT" | "RIGHT";
