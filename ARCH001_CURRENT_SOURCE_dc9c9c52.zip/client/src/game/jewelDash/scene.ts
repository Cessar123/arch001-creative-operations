import { loadBabylonRuntime } from "./babylonRuntime";
import { JewelDashWorld } from "./JewelDashWorld";
import type { DashDirection, DashSnapshot } from "./types";

export type JewelDashHandle = {
  scene: any;
  move: (direction: DashDirection) => void;
  restart: () => void;
  dispose: () => void;
};

export async function createJewelDashScene(
  engine: any,
  canvas: HTMLCanvasElement,
  options: { demo: boolean; onSnapshot: (snapshot: DashSnapshot) => void },
): Promise<JewelDashHandle> {
  const B = await loadBabylonRuntime();
  const scene = new B.Scene(engine);
  const camera = new B.ArcRotateCamera("jewel-camera", -Math.PI / 2, 1.08, 17, new B.Vector3(0, 0.2, 10), scene);
  camera.fov = 0.74;
  camera.lowerRadiusLimit = 17;
  camera.upperRadiusLimit = 17;
  camera.lowerBetaLimit = 1.08;
  camera.upperBetaLimit = 1.08;
  camera.attachControl(canvas, false);

  const skyLight = new B.HemisphericLight("sky-light", new B.Vector3(0, 1, 0), scene);
  skyLight.intensity = 1.25;
  skyLight.diffuse.set(0.5, 0.83, 1);
  skyLight.groundColor.set(0.01, 0.04, 0.09);

  const world = new JewelDashWorld(scene, B, options.onSnapshot, options.demo);
  scene.onBeforeRenderObservable.add(() => {
    world.update(engine.getDeltaTime() / 1000);
  });

  return {
    scene,
    move: (direction) => world.move(direction),
    restart: () => world.restart(),
    dispose: () => {
      camera.detachControl();
      world.dispose();
      scene.dispose();
    },
  };
}
