import { LANE_POSITIONS, initialDashSnapshot, resolveContact } from "./rules";
import type { DashDirection, DashObjectKind, DashSnapshot } from "./types";

type MovingEntity = {
  kind: DashObjectKind;
  lane: number;
  mesh: any;
};

const SPAWN_PATTERN: Array<{ kind: DashObjectKind; lane: number }> = [
  { kind: "shard", lane: 0 },
  { kind: "gate", lane: 1 },
  { kind: "shard", lane: 2 },
  { kind: "barrier", lane: 0 },
  { kind: "gate", lane: 2 },
  { kind: "shard", lane: 1 },
  { kind: "barrier", lane: 2 },
  { kind: "shard", lane: 0 },
];

export class JewelDashWorld {
  private snapshot = initialDashSnapshot();
  private entities: MovingEntity[] = [];
  private player: any;
  private spawnTimer = 0;
  private spawnIndex = 0;
  private demoTimer = 0;
  private lastSignature = "";

  constructor(
    private readonly scene: any,
    private readonly B: any,
    private readonly onSnapshot: (snapshot: DashSnapshot) => void,
    private readonly demo = false,
  ) {
    scene.clearColor = new this.B.Color4(0.01, 0.035, 0.07, 1);
    this.createTrack();
    this.player = this.createPlayer();
    this.emit();
  }

  move(direction: DashDirection) {
    if (this.snapshot.status !== "RUNNING") return;
    const nextLane = Math.max(0, Math.min(2, this.snapshot.lane + (direction === "LEFT" ? -1 : 1)));
    if (nextLane === this.snapshot.lane) return;
    this.snapshot = { ...this.snapshot, lane: nextLane, signal: direction === "LEFT" ? "تحرك يساراً" : "تحرك يميناً" };
    this.player.position.x = LANE_POSITIONS[nextLane];
    this.emit();
  }

  restart() {
    this.entities.forEach((entity) => entity.mesh.dispose());
    this.entities = [];
    this.snapshot = initialDashSnapshot();
    this.spawnTimer = 0;
    this.spawnIndex = 0;
    this.player.position.x = LANE_POSITIONS[this.snapshot.lane];
    this.emit();
  }

  update(delta: number) {
    if (this.snapshot.status !== "RUNNING") return;

    if (this.demo) {
      this.demoTimer += delta;
      if (this.demoTimer > 1.2) {
        this.demoTimer = 0;
        const targetLane = (this.snapshot.lane + 1) % 3;
        this.move(targetLane > this.snapshot.lane ? "RIGHT" : "LEFT");
      }
    }

    this.spawnTimer += delta;
    if (this.spawnTimer >= 1.25) {
      this.spawnTimer = 0;
      this.spawnNext();
    }

    const speed = 8.2;
    for (let index = this.entities.length - 1; index >= 0; index -= 1) {
      const entity = this.entities[index];
      entity.mesh.position.z -= speed * delta;
      entity.mesh.rotation.y += delta * (entity.kind === "gate" ? 1.2 : 2.4);

      if (entity.mesh.position.z < 1.2) {
        if (entity.lane === this.snapshot.lane) {
          this.snapshot = resolveContact(this.snapshot, entity.kind);
          this.emit();
        }
        entity.mesh.dispose();
        this.entities.splice(index, 1);
      }
    }
  }

  dispose() {
    this.entities.forEach((entity) => entity.mesh.dispose());
    this.entities = [];
  }

  private createTrack() {
    const roadMaterial = new this.B.StandardMaterial("road-mat", this.scene);
    roadMaterial.diffuseColor = new this.B.Color3(0.025, 0.09, 0.16);
    roadMaterial.specularColor = new this.B.Color3(0.05, 0.6, 0.85);

    const road = this.B.MeshBuilder.CreateGround("jewel-road", { width: 12, height: 58 }, this.scene);
    road.position.z = 15;
    road.material = roadMaterial;

    const laneMaterial = new this.B.StandardMaterial("lane-mat", this.scene);
    laneMaterial.emissiveColor = new this.B.Color3(0.08, 0.95, 1);
    laneMaterial.alpha = 0.72;
    [-1.5, 1.5].forEach((x, index) => {
      const line = this.B.MeshBuilder.CreateBox(`lane-line-${index}`, { width: 0.06, height: 0.035, depth: 58 }, this.scene);
      line.position = new this.B.Vector3(x, 0.03, 15);
      line.material = laneMaterial;
    });

    const cityMaterial = new this.B.StandardMaterial("city-mat", this.scene);
    cityMaterial.diffuseColor = new this.B.Color3(0.025, 0.18, 0.29);
    cityMaterial.emissiveColor = new this.B.Color3(0.01, 0.2, 0.32);
    for (let index = 0; index < 16; index += 1) {
      const side = index % 2 === 0 ? -1 : 1;
      const width = 1 + (index % 3) * 0.35;
      const height = 2.8 + (index % 5) * 0.75;
      const building = this.B.MeshBuilder.CreateBox(`city-block-${index}`, { width, height, depth: 1.6 }, this.scene);
      building.position = new this.B.Vector3(side * (7.5 + (index % 3) * 0.8), height / 2, 6 + index * 3.6);
      building.material = cityMaterial;
    }
  }

  private createPlayer() {
    const jewelMaterial = new this.B.StandardMaterial("jewel-mat", this.scene);
    jewelMaterial.diffuseColor = new this.B.Color3(0.95, 0.58, 0.08);
    jewelMaterial.emissiveColor = new this.B.Color3(0.9, 0.42, 0.03);

    const player = this.B.MeshBuilder.CreateSphere("original-jewel", { diameter: 0.95, segments: 16 }, this.scene);
    player.position = new this.B.Vector3(LANE_POSITIONS[this.snapshot.lane], 0.6, 1);
    player.material = jewelMaterial;

    const ringMaterial = new this.B.StandardMaterial("jewel-ring-mat", this.scene);
    ringMaterial.emissiveColor = new this.B.Color3(0.08, 0.92, 1);
    const ring = this.B.MeshBuilder.CreateTorus("jewel-ring", { diameter: 1.5, thickness: 0.06, tessellation: 24 }, this.scene);
    ring.position = new this.B.Vector3(player.position.x, 0.12, 1);
    ring.rotation.x = Math.PI / 2;
    ring.material = ringMaterial;
    ring.parent = player;
    ring.position = new this.B.Vector3(0, -0.46, 0);
    return player;
  }

  private spawnNext() {
    const next = SPAWN_PATTERN[this.spawnIndex % SPAWN_PATTERN.length];
    this.spawnIndex += 1;
    const mesh = this.createEntityMesh(next.kind);
    mesh.position = new this.B.Vector3(LANE_POSITIONS[next.lane], next.kind === "gate" ? 1.5 : 0.65, 23);
    this.entities.push({ ...next, mesh });
  }

  private createEntityMesh(kind: DashObjectKind) {
    if (kind === "gate") {
      const material = new this.B.StandardMaterial("gate-mat", this.scene);
      material.emissiveColor = new this.B.Color3(0.03, 0.92, 1);
      const gate = this.B.MeshBuilder.CreateTorus(`district-gate-${this.spawnIndex}`, { diameter: 1.65, thickness: 0.15, tessellation: 28 }, this.scene);
      gate.material = material;
      return gate;
    }

    if (kind === "barrier") {
      const material = new this.B.StandardMaterial("barrier-mat", this.scene);
      material.diffuseColor = new this.B.Color3(0.12, 0.16, 0.24);
      material.emissiveColor = new this.B.Color3(0.6, 0.05, 0.05);
      const barrier = this.B.MeshBuilder.CreateBox(`barrier-${this.spawnIndex}`, { width: 1.55, height: 1.2, depth: 0.55 }, this.scene);
      barrier.material = material;
      return barrier;
    }

    const material = new this.B.StandardMaterial("shard-mat", this.scene);
    material.diffuseColor = new this.B.Color3(1, 0.72, 0.14);
    material.emissiveColor = new this.B.Color3(0.95, 0.52, 0.05);
    const shard = this.B.MeshBuilder.CreatePolyhedron(`shard-${this.spawnIndex}`, { type: 1, size: 0.7 }, this.scene);
    shard.material = material;
    return shard;
  }

  private emit() {
    const signature = JSON.stringify(this.snapshot);
    if (signature === this.lastSignature) return;
    this.lastSignature = signature;
    this.onSnapshot({ ...this.snapshot });
  }
}
