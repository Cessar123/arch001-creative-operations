# Jewel Dash Memory

- The active ARCH-001 website is a production operations console; `/game` must remain a separate route and must not replace the operations homepage.
- DNA LOCK identities remain untouched. The playable object is the non-human Original Jewel, not a registered character face.
- The initial game has intentionally low technical risk: no physics plugin, GLB importer, procedural terrain, complex shader, or online multiplayer.
- The intended interaction is portrait mobile browser play. Keyboard controls exist only as a desktop fallback.
- Babylon is loaded from the official runtime CDN only when `/game` opens. This preserves a playable Babylon game while avoiding the sandbox's production-build memory ceiling from eagerly transforming the full engine with the existing operations bundle.
- Mobile visual verification is performed through `/game?demo` at 375×812. The developer preview and type/test checks pass; a local Vite production build remains memory-constrained by the existing full operations bundle.
