import { describe, expect, it } from "vitest";
import { archCharacters, getArchRegistryPayload } from "../shared/arch001";
import { FOXY_CHAT_COMMAND, FOXY_GOVERNANCE, FOXY_PROFILE } from "../shared/foxy";

describe("Foxy ARCH-001 registration", () => {
  it("keeps Foxy registered as a locked D01 strategic assistant with a stable QR payload", () => {
    const foxy = archCharacters.find((character) => character.id === "FOXY-AI-001");

    expect(foxy).toMatchObject({
      name: "Foxy / فوكسى",
      district: "D01",
      status: "LOCKED",
      work: "استوديو الموقع والشات",
    });
    expect(getArchRegistryPayload(foxy!)).toContain("arch001://registry/FOXY-AI-001");
  });

  it("exposes website and chat proposals but protects publishing, secrets, and canon", () => {
    expect(FOXY_PROFILE.clearance).toBe("GOVERNED FULL ACCESS");
    expect(FOXY_CHAT_COMMAND).toContain("SITE-BRIEF");
    expect(FOXY_GOVERNANCE.may).toContain("اقتراح بنية الموقع والواجهات ونصوصها");
    expect(FOXY_GOVERNANCE.cannot).toContain("نشر موقع أو تغيير أسرار أو صلاحيات مستخدمين بنفسها");
    expect(FOXY_GOVERNANCE.cannot).toContain("تعديل Original Jewel أو System Jewel أو DNA LOCK");
    expect(FOXY_GOVERNANCE.cannot.join(" ")).toContain("اختلاق حالة للمدينة");
    expect(FOXY_GOVERNANCE.cannot.join(" ")).toContain("تنفيذ فعل خارجي");
    expect(FOXY_GOVERNANCE.attribution).toContain("أفكار مصطفى");
    expect(FOXY_CHAT_COMMAND).toContain("STATE QUERY");
    expect(FOXY_CHAT_COMMAND).toContain("PENDING DATA");
  });

  it("records the reviewed DNA sheets as locked character assets", () => {
    const reviewedIds = [
      "ZAZA-FAMILY-009-A",
      "MOHAMED-SHEHATA-FAMILY-010",
      "MAKKA-SHEHATA-FAMILY-010-A",
      "OSAMA-SHEHATA-FAMILY-010-B",
      "OUDI-IMPS-005",
      "LOUMA-FAMILY-009",
    ];

    for (const id of reviewedIds) {
      const character = archCharacters.find((entry) => entry.id === id);
      expect(character).toMatchObject({ status: "LOCKED" });
      expect(character?.visualSheetUrl).toMatch(/^\/manus-storage\/dna_lock_/);
    }
  });

  it("records Louma's reviewed independent DNA sheet and preserves his distinction from Zaza", () => {
    const louma = archCharacters.find((character) => character.id === "LOUMA-FAMILY-009");

    expect(louma).toMatchObject({ status: "LOCKED" });
    expect(louma?.visualSheetUrl).toMatch(/^\/manus-storage\/dna_lock_louma_el_sharasy_/);
    expect(louma?.pendingVisualSheetUrl).toBeUndefined();
    expect(louma?.visualReferenceNote).toBeUndefined();
    expect(louma?.visualLock).toContain("بدلة كحلية");
    expect(louma?.visualLock).toContain("ربطة عنق خمرية");
  });
});
