import { describe, expect, it } from "vitest";
import { initialDashSnapshot, resolveContact } from "../client/src/game/jewelDash/rules";

describe("Jewel Dash game rules", () => {
  it("rewards shards and gates while building a streak", () => {
    const shard = resolveContact(initialDashSnapshot(), "shard");
    const gate = resolveContact(shard, "gate");

    expect(shard.score).toBe(12);
    expect(gate.score).toBeGreaterThan(shard.score);
    expect(gate.streak).toBe(2);
  });

  it("removes shields and ends the run after three barriers", () => {
    const once = resolveContact(initialDashSnapshot(), "barrier");
    const twice = resolveContact(once, "barrier");
    const finalHit = resolveContact(twice, "barrier");

    expect(once.shields).toBe(2);
    expect(twice.status).toBe("RUNNING");
    expect(finalHit.shields).toBe(0);
    expect(finalHit.status).toBe("GAME_OVER");
  });
});
