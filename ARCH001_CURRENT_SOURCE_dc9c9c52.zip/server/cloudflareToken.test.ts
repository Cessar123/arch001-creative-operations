import { describe, expect, it } from "vitest";

const cloudflareToken = process.env.CLOUDFLARE_API_TOKEN;
const shouldValidateToken = process.env.CLOUDFLARE_TOKEN_VALIDATION === "true";

describe.skipIf(!cloudflareToken || !shouldValidateToken)("Cloudflare API token", () => {
  it("verifies the supplied token with Cloudflare", async () => {
    const response = await fetch("https://api.cloudflare.com/client/v4/user/tokens/verify", {
      headers: {
        Authorization: `Bearer ${cloudflareToken}`,
      },
    });

    const payload = (await response.json()) as { success?: boolean };
    expect(response.ok).toBe(true);
    expect(payload.success).toBe(true);
  });
});
