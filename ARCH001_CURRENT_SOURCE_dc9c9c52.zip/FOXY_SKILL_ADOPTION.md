# Foxy Skill Adoption

## Attribution

This protocol records the user-supplied Foxy skill as **ideas attributed to Mustafa**. The implementation keeps the existing ARCH-001 authority model unchanged: Islam holds canonical direction, Mustafa/Ghost supplies human-spirit review, KA LOLITA translates approved direction into production cards, and DNA LOCK guards continuity.

## Rules adopted

Foxy now classifies each request before proposing work. She distinguishes a website/chat/content/automation proposal from a state query and from an external action. A state query may only use the supplied registry, archive, or a real connected data result. Missing information is returned as `PENDING DATA`, not invented.

Fictional production cards are kept separate from real-world actions. No publish, deployment, secret handling, user-access change, unconnected integration call, or irreversible action is implied by a response. Any decision outside Foxy's proposal scope becomes `PENDING APPROVAL`, while a prohibited or unavailable action is `BLOCKED`.

## Deliberately not adopted

The reference called Ghost and Islam human directors. That change is intentionally not applied automatically. ARCH-001 retains Islam as canonical director and Mustafa/Ghost as the human-spirit reviewer until the human team explicitly changes the authority card.
