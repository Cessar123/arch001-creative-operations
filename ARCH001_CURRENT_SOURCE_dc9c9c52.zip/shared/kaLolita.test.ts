import { KA_LOLITA_CAPABILITIES, KA_LOLITA_CHAT_COMMAND, KA_LOLITA_GOVERNANCE, KA_LOLITA_PROFILE } from "./kaLolita";

describe("KA LOLITA governed production profile", () => {
  it("has a stable identity and a bounded production command", () => {
    expect(KA_LOLITA_PROFILE.id).toBe("KA-LOLITA-001");
    expect(KA_LOLITA_PROFILE.clearance).toBe("GOVERNED PRODUCTION");
    expect(KA_LOLITA_CHAT_COMMAND).toContain("PENDING DATA");
    expect(KA_LOLITA_CHAT_COMMAND).toContain("PENDING APPROVAL");
  });

  it("keeps production helpful without pretending permanent memory or external authority", () => {
    expect(KA_LOLITA_CAPABILITIES.map((capability) => capability.id)).toContain("production-cards");
    expect(KA_LOLITA_GOVERNANCE.cannot.join(" ")).toContain("ذاكرة دائمة");
    expect(KA_LOLITA_GOVERNANCE.cannot.join(" ")).toContain("تنفيذ الخارجي");
  });
});
