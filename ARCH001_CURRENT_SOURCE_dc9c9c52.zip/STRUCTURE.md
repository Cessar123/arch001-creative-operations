# Jewel Dash Structure

| Layer | Responsibility |
|---|---|
| `client/src/pages/JewelDash.tsx` | React route shell, portrait HUD, touch buttons, game status, and route back to the operations console. |
| `client/src/components/GameCanvas.tsx` | Babylon engine lifecycle: one engine instance, canvas sizing, resize cleanup, and scene disposal. |
| `client/src/game/jewelDash/scene.ts` | Creates the Babylon scene and exports the game handle consumed by the canvas. |
| `client/src/game/jewelDash/JewelDashWorld.ts` | Owns lane state, spawn sequence, score, shield count, collision checks, demo mode, and cleanup. |
| `client/src/game/jewelDash/types.ts` | Shared game events and public UI snapshot types. |

The React layer never decides collision or scoring. The game world emits a compact snapshot to the React HUD. The game route is isolated from the existing ARCH-001 registry, chat, and authenticated production workflow.
