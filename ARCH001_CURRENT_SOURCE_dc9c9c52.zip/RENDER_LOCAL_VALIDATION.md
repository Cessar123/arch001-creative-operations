# Render Local Validation

## Result

The ARCH-001 production bundle completed successfully when the configured build steps were executed through the project-local binaries:

```bash
./node_modules/.bin/vite build
./node_modules/.bin/esbuild server/_core/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist
```

The result contains `dist/public` and `dist/index.js`, which matches the `pnpm build` script and the `pnpm start` entrypoint in `package.json`.

## Corepack note

The sandbox's bundled Corepack failed before dependency installation because of an upstream signing-key mismatch. This failure is not a project source error. To avoid coupling a Render build to that broken bootstrap path, `render.yaml` now installs the pinned pnpm version directly before its frozen-lockfile installation.

## Deployment decision

No Render service was created. The user chose the existing Cloudflare Worker public preview, so Render remains a validated but inactive alternative. Any future Render deployment still requires the non-secret environment variables listed in `render.yaml` and a renewed GitHub sync.
